jQuery(document).ready(function($) {
	console.log('Document Ready');

	// slick slider
  $('.featured-testimonial-slider').slick({
    arrows: true,
    dots: true,
    speed: 300,
    slidesToShow: 2,
    slidesToScroll: 1,
    adaptiveHeight: true,
    responsive: [
      {
        breakpoint: 780,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          infinite: true,
          arrows: true,
          dots: true,
          adaptiveHeight: true,
        }
      }
      ]
  });	

});