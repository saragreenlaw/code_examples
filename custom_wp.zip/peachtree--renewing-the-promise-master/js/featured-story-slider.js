jQuery(document).ready(function($) {
	console.log('Document Ready');

	// slick slider
  $('.featured-story-slider').slick({
	dots: true,
	arrows: true,
	adaptiveHeight: true
  });	

});