jQuery(document).ready(function($){

    $('.tabs').tabslet({
     active :1,
     animation : true
     });
    
    });