
$(document).ready(function(){ 
      $('.gallery').slickLightbox({ 
         itemSelector: '> a' 
      }); 
   });
   