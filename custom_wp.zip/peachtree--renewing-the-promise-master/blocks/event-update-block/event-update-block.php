<?php
/**
 * Block template file: event-update-block.php
 *
 * Event Update Block Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'event-update-block-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-event-update-block';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>

<style type="text/css">
	<?php echo '#' . $id; ?> {
		/* Add styles that use ACF values here */
	}
</style>

<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">
	<h2 class= "cpt-header-block"><?php the_field( 'header' ); ?></h2>
	<?php if(get_field('what_type_of_post_would_you_like_to_display') == "Event"): ?>
		<?php
			$args = array(
    		'post_type' => 'event',
    		'posts_per_page' => 4
			);
			$the_query = new WP_Query( $args ); ?>
		<?php if ( $the_query->have_posts() ) : ?>
			<div class="custom-block-loop-section">
        		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
				
				<?php 
				$id = get_the_ID();
				$event_date = get_field('event_date', $id); 
				?>
	       			 <div class="custom-block-loop">
	            		<?php if ( has_post_thumbnail() ) { ?>
                   			 <div class="featured-image">
                        		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                    		</div>
                		<?php } ?>
						<p class="date"><?php echo $event_date; ?></p>
                		<h2 class="wp-block-post-title"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		        		<p><?php the_excerpt(); ?></p>
		        		<p class="wp-block-post-excerpt__more-text"><a class="wp-block-post-excerpt__more-link" href="<?php the_permalink(); ?>">Learn More</a></p>
	        		</div>
        		<?php endwhile; ?>
			</div>
		<?php wp_reset_postdata(); ?>
		<?php endif; ?>
		<?php endif; ?>
		
		<?php if(get_field('what_type_of_post_would_you_like_to_display') == "Updates"): ?>
			<?php
			$args = array(
    		'post_type' => 'updates',
    		'posts_per_page' => 4
			);
			$the_query = new WP_Query( $args ); ?>
		<?php if ( $the_query->have_posts() ) : ?>
			<div class="custom-block-loop-section">
        		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
	       			 <div class="custom-block-loop">
	            		<?php if ( has_post_thumbnail() ) { ?>
                   			 <div class="featured-image">
                        		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                    		</div>
                		<?php } ?>
						<p class="date"><?php echo get_the_date('F j, Y'); ?></p>
                		<h2 class="wp-block-post-title"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		        		<p><?php the_excerpt(); ?></p>
		        		<p class="wp-block-post-excerpt__more-text"><a class="wp-block-post-excerpt__more-link" href="<?php the_permalink(); ?>">Learn More</a></p>
	        		</div>
        		<?php endwhile; ?>
			</div>
		<?php wp_reset_postdata(); ?>
		<?php endif; ?>
	<?php endif; ?>

		<?php if(get_field('what_type_of_post_would_you_like_to_display') == "Devotional"): ?>
			<?php
			$args = array(
    		'post_type' => 'devotional',
    		'posts_per_page' => 4
			);
			$the_query = new WP_Query( $args ); ?>
		<?php if ( $the_query->have_posts() ) : ?>
			<div class="custom-block-loop-section">
        		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
				<?php 
				$id = get_the_ID();
				$date = get_field('date', $id); 
				?>
	       			 <div class="custom-block-loop">
	            		<?php if ( has_post_thumbnail() ) { ?>
                   			 <div class="featured-image">
                        		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                    		</div>
                		<?php } ?>
						<p class="date"><?php echo $date; ?></p>
                		<h2 class="wp-block-post-title"> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		        		<?php the_excerpt(); ?>
		        		<p class="wp-block-post-excerpt__more-text"><a class="wp-block-post-excerpt__more-link" href="<?php the_permalink(); ?>">Continue Reading</a></p>
	        		</div>
        		<?php endwhile; ?>
			</div>
		<?php wp_reset_postdata(); ?>
		<?php endif; ?>
		<?php endif; ?>
</div>