<?php 
include('blocks.categories.php');
include('blocks.blocks.php');
include('acf.blocks.php');
include('acf.blocks.php');