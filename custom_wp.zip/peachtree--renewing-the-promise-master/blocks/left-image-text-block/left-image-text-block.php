<?php
/**
 * Block template file: left-image-text-block.php
 *
 * Lit Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'lit-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-lit';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>

<style type="text/css">
	<?php echo '#' . $id; ?> {
		/* Add styles that use ACF values here */
	}
</style>

<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">
<div class="wrap">
	<?php $image = get_field( 'image' ); ?>
	<?php $size = 'full'; ?>
	<?php if ( $image ) : ?>
		<div class="image-wrap">
		<div class="image-stack">
		<div class="image-stack__item image-stack__item--top">
		<?php echo wp_get_attachment_image( $image, $size ); ?>
	</div>
	<div class="image-stack__item image-stack__item--bottom">
      <img src="/wp-content/themes/peachtree--renewing-the-promise/images/left-image-background.png" alt="">
    </div>
	</div>
	</div>
	<?php endif; ?>
	<div class="content-wrap">
	<div class="headline header-gold-border">
	<?php the_field( 'header' ); ?>
	</div>
	<p>
	<?php the_field( 'content' ); ?>
</p>
<?php 
                $link = get_field('button_url');
                if( $link ): ?>
                     <a class="button" href="<?php echo esc_url( $link ); ?>"><?php echo the_field( 'button_link' ); ?></a>
                <?php endif; ?>
	</div>
				</div>

</div>