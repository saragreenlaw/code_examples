<?php
/**
 * Block template file: home-story-block.php
 *
 * Hsb Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */
include(CCC_ACF_BLOCK_PATH.'blocks.settings.php'); 

// Create id attribute allowing for custom "anchor" value.
$id = 'fsb-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-fsb';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>
<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">

            <?php
			$args = array(
    		'post_type' => 'stories',
    		'posts_per_page' => -1,
			'meta_key'       => 'feature_story',
            'meta_value'     => 'yes',
           
			);
			$the_query = new WP_Query( $args ); ?>
   <div class="custom-featured-stories-section">
	        <?php if ( $the_query->have_posts() ) : ?>
                        <div class="featured-story-slider">
        		            <?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
							 <div class="single-featured-story">
				            <?php 
                            // Get the post id
                            $id = get_the_ID();
                            // Get the name
			                $name = get_field('name', $id); 
                            // Get the excerpt
			                $excerpt = get_field('excerpt_for_story_slider_page', $id); 
                            // Get the image
                            $image = get_field('image', $id);
                            // Get the embed URL
                            $embed_url = get_field('video_link', $id);
							// Get the embed URL
                            $ovideo = get_field('oembed', $id);
                            ?>
                                <div class="content-wrap">
                                    <div class="quote"></div>
                                        <p><?php echo $excerpt; ?></p>
                                        <p class="read-more"><a href="<?php the_permalink(); ?>">Read More</a></p>
                                        <h3><a href="<?php the_permalink(); ?>"><?php echo $name; ?></a></h3>
								 </div>
								   <div class="image">
									   <?php echo $ovideo; ?>
                                     <?php $image = get_field( 'image', $id ); ?>
                                    <?php if ( $image ) : ?>
	                                <img src="<?php echo esc_url( $image['url'] ); ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" />
                                <?php endif; ?>
								 </div>
							</div>
        		                <?php endwhile; ?>
                                    </div>
		                        <?php wp_reset_postdata(); ?>
		                         <?php endif; ?>
                        
	</div></div>


   