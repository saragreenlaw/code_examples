<?php
/**
 * Block template file: information-image-blocks.php
 *
 * Iib Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'iib-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-iib';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>

<style type="text/css">
	<?php echo '#' . $id; ?> {
		/* Add styles that use ACF values here */
	}
</style>

<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">
	<?php if ( have_rows( 'add_a_image_informational_block' ) ) : ?>
        <div class="info-image-block">
		    <?php while ( have_rows( 'add_a_image_informational_block' ) ) : the_row(); ?>
                <div class="container">
			        <?php if ( get_sub_field( 'image' ) ) : ?>
				        <img class="image" src="<?php the_sub_field( 'image' ); ?>" />
			        <?php endif ?>
                        <div class="headline">
			                <?php the_sub_field( 'headline' ); ?>
                        </div>
                            <div class="hover-overlay">
                                <div class="hover-content">
                                    <div class="hover-headline">
                                    <div class="yellow-border"></div>
                                    </div>
			                        <p><?php the_sub_field( 'hover_content' ); ?></p>
                                         <?php 
                                            $link = get_sub_field('link_url');
                                            if( $link ): ?>
                                            <a class="cta-link" href="<?php echo esc_url( $link ); ?>"><?php the_sub_field( 'link_text' ); ?></a>
                                        <?php endif; ?>
                                </div>    
                            </div>
                </div>
		    <?php endwhile; ?>
	            <?php else : ?>
		        <?php // No rows found ?>
        </div>
	<?php endif; ?>
</div>