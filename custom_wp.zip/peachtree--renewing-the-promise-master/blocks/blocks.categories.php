<?php

add_filter( 'block_categories', function( $categories, $post ) {

	if( get_field('client_full_name', 'option') ) {
		$prefix = get_field('client_full_name', 'option');
	} else {
		$prefix = '{{CLIENT FULL NAME}}';
	}

	return array_merge(
		$categories,
		array(
			array(
				'title' => __($prefix.' | Callouts'),
				'slug'  => prefix().'-callouts'
			),
		)
	);
}, 10, 2 );

