<?php
/**
 * Block template file: story-block.php
 *
 * Storyblock Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'storyblock-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-storyblock';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>

<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">
	<h2><?php the_field( 'headline' ); ?></h2>


<?php
			$args = array(
    		'post_type' => 'stories',
    		'posts_per_page' => -1,
			'meta_query'    => array(
				'relation'      => 'AND',
				array(
					'key'       => 'dispaly_on_stories_page',
					'value'     => 'yes',
					'compare'   => 'IN',
				),
				array(
					'key'       => 'feature_story',
					'value'     => 'no',
					'compare'   => 'IN',
				),
			),
		);
			
		$the_query = new WP_Query( $args ); ?>
		<?php if ( $the_query->have_posts() ) : ?>
			<div class="custom-stories-section">
				<div class="featured-testimonial-slider">
        			<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
						<?php 
            			// Get the post id
            			$id = get_the_ID();
            			// Get the name
						$name = get_field('name', $id); 
        				?>
        					<div class="single-testimonial-slider">
							<div class="quote"></div>
								<div class="testimonial-slider-content">
                					<p><?php echo get_the_content(); ?></p>
									<h3><a href="<?php the_permalink(); ?>"><?php echo $name; ?></a></h3>
								</div>
            				</div>
        			<?php endwhile; ?>
					<?php wp_reset_postdata(); ?>
				</div>
			</div>
		<?php endif; ?>	
		</div>