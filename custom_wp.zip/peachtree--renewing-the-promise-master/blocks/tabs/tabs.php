<?php
/**
 * Block template file: tabs.php
 *
 * Tabs Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'tabs-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-tabs';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>
<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">
<h2 class="headline"><?php the_field( 'headline' ); ?></h2>
<p class="subheader"><?php the_field( 'subheader' ); ?></p>

<div class="tabs">
     <ul class="horizontal">
	    <?php if( have_rows('tabs') ):
            $i = 1;
            while ( have_rows('tabs' ) ) : the_row();
        echo '<li><a href="#tab-' . $i . '">' . get_sub_field( "tab_header" ) . '</a></li>';
             $i++;
             endwhile;
echo '</ul>';
            $i = 1;
            while ( have_rows('tabs') ) : the_row();
echo '<div id="tab-' . $i . '">';
        if ( have_rows( 'content' ) ) : ?>
        <?php while ( have_rows( 'content' ) ) : the_row(); ?>
        <?php if ( have_rows( 'map_key' ) ) : ?>
                <div class="key">
						<?php while ( have_rows( 'map_key' ) ) : the_row(); ?>
                        <div class="content">
						<p class="letter">	<?php the_sub_field( 'letter' ); ?></p>
						<p class="name">	<?php the_sub_field( 'name' ); ?></p>
            </div>
						<?php endwhile; ?>
                        </div>
					<?php else : ?>
						<?php // No rows found ?>
					<?php endif; ?>
        <!-- map image -->
            <?php if ( get_sub_field( 'map_image' ) ) : ?>
             <img class="map-image" src="<?php the_sub_field( 'map_image' ); ?>" />
            <?php endif ?>
        <!-- end map image section  -->

        <!-- map content  -->
            <?php if ( have_rows( 'map_content' ) ) : ?>
                <div class="map-content">
                    <?php while ( have_rows( 'map_content' ) ) : the_row(); ?>
                <div class="content-section">
                    <div class="copy-section">
                        <?php $map_image_label = get_sub_field( 'map_image_label' ); ?>
                            <?php if ( $map_image_label ) : ?>
                            <img class="number-label" src="<?php echo esc_url( $map_image_label['url'] ); ?>" alt="<?php echo esc_attr( $map_image_label['alt'] ); ?>" />
                            <?php endif; ?>
                        <h3><?php the_sub_field( 'header' ); ?></h3>
                        <?php the_sub_field( 'content' ); ?>
                        <?php 
                        $link = get_sub_field('video_url');
                        if( $link ): ?>
                         <a class="button" href="<?php echo esc_url( $link ); ?>" data-featherlight="iframe" data-featherlight-iframe-width="960" data-featherlight-iframe-height="540"><?php the_sub_field( 'button_label' ); ?></a>
                        <?php endif; ?>
                    </div>  <!-- end copy section div -->
                
                    <div class="image-section">

                    <?php 
$images = get_sub_field('slider_images');
$img_count=1;
if( $images ): ?>
     <div class="gallery"> 
        <?php foreach( $images as $image ):?>
       
<?php if ($img_count == 1) { ?>

<div class="large">
                <a rel="gallery" href="<?php echo $image['url']; ?>">
                     <img src="<?php echo $image['sizes']['large']; ?>" alt="<?php echo $image['alt']; ?>" />
                </a>                
            </div>
           
<?php } else {?>

            <div class="thumb">
                <a rel="gallery" href="<?php echo $image['url']; ?>">
                     <img src="<?php echo $image['sizes']['thumbnail']; ?>" alt="<?php echo $image['alt']; ?>" />
                </a>                
            </div>
            
<?php } 
$img_count++; ?>
        <?php endforeach; ?>    
         </div> <!-- end div gallery section  -->
<?php endif; ?>

                    </div> <!-- end div image section  -->



                    </div> <!-- end content section div -->
                    
              
                    <?php endwhile; ?>
                 
                </div> <!-- end map content section div -->
                    <?php else : ?>
                        <?php // No rows found ?>
                             <?php endif; ?>
                                 <?php endwhile; ?>
                    <?php else : ?>
                        <?php // No rows found ?>
                    <?php endif; 
    echo '</div>';// end tab id section div
        $i++;
        endwhile;
echo '</div>'; // end tab section div
else :
    // no rows found
endif; ?>
</div> <!-- end block id section div -->