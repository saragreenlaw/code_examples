<?php
/**
 * Block template file: home-story-block.php
 *
 * Hsb Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'hsb-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-hsb';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>

<style type="text/css">
	<?php echo '#' . $id; ?> {
		/* Add styles that use ACF values here */
	}
</style>

<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">
<?php
           global $post;
           $featured = get_field('choose_a_featured_story');
           if( $featured ): ?>
           <?php foreach( $featured as $post): ?>
           <?php setup_postdata($post); ?>

            <?php 
            // Get the post id
            $id = get_the_ID();
            // Get the name
			$name = get_field('name', $id); 
            // Get the image
            $image = get_field('image', $id);
            // Get the embed URL
            $embed_url = get_field('video_link', $id);
                ?>
           <div class="featured-story" style="background-image: url(<?php the_field('background_image'); ?>);">
                <div class="featured-story-wrap">
                    <?php if ( get_field( 'video_link', $id ) ): ?>
                         <div class="image-video-wrap">
                            <div class="bg-single-video">
                                <div class="bg-single-video-container" data-bg-video-url="<?=$embed_url?>" style="background-image: url(<?=$image['sizes']['large']?>);">
                                    <div class="play-button">
    		                            <i class="fas fa-play"></i>
                                    </div>
                                </div>
                            </div>
                         </div>
                         <div class="quote"></div>
                        <div class="content-wrap">
                            <p><?php echo get_the_content(); ?></p>
                            <h3><a href="<?php the_permalink(); ?>"><?php echo $name; ?></a></h3>
                            <?php $button_link = get_field( 'button_link' ); ?>
	                        <?php if ( $button_link ) : ?>
		                    <a class="button home featured" href="<?php echo esc_url( $button_link) ; ?>"><?php the_field( 'button_text' ); ?></a>
                        </div>
	                        <?php endif; ?>
                     <?php else:?>
                        <div class="quote"></div>
                        <div class="content-wrap">
                            <p><?php echo get_the_content(); ?></p>
                            <h3><a href="<?php the_permalink(); ?>"><?php echo $name; ?></a></h3>
                        <?php $button_link = get_field( 'button_link' ); ?>
	                        <?php if ( $button_link ) : ?>
		                    <a class="button home featured" href="<?php echo esc_url( $button_link) ; ?>"><?php the_field( 'button_text' ); ?></a>
	                        <?php endif; ?>
                        </div>
                        <?php $image = get_field( 'image', $id ); ?>
                            <?php if ( $image ) : ?>
	                            <img src="<?php echo esc_url( $image['url'] ); ?>" alt="<?php echo esc_attr( $image['alt'] ); ?>" />
                            <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <?php wp_reset_postdata(); ?>
            <?php endif; ?>
</div>