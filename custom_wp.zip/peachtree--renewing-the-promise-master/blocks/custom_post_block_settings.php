<?php
/**
 * Load Blocks
 */
add_action( 'init', 'register_cpb_blocks' );
function register_cpb_blocks() {
    register_block_type( get_template_directory() . '/blocks/custom_post_block/block.json' );
}
