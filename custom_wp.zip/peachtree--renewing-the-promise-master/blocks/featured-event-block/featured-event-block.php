<?php
/**
 * Block template file: featured-event-block.php
 *
 * Fev Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */

// Create id attribute allowing for custom "anchor" value.
$id = 'fev-' . $block['id'];
if ( ! empty($block['anchor'] ) ) {
    $id = $block['anchor'];
}

// Create class attribute allowing for custom "className" and "align" values.
$classes = 'block-fev';
if ( ! empty( $block['className'] ) ) {
    $classes .= ' ' . $block['className'];
}
if ( ! empty( $block['align'] ) ) {
    $classes .= ' align' . $block['align'];
}
?>

<style type="text/css">
	<?php echo '#' . $id; ?> {
		/* Add styles that use ACF values here */
	}
</style>

<div id="<?php echo esc_attr( $id ); ?>" class="<?php echo esc_attr( $classes ); ?>">
<div class="featured-events-header-section">
<div class="featured-events-headline header-gold-border">
	<?php the_field( 'headline' ); ?>
</div>
    <a class="more-link" href="/events"> See All Events</a>
</div>
    <?php
			$args = array(
    		'post_type' => 'event',
    		'posts_per_page' => 3,
		);
			
		$the_query = new WP_Query( $args ); ?>
		<?php if ( $the_query->have_posts() ) : ?>
            <div class="featured-events-section">
        			<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

						<?php 
            			// Get the post id
            			$id = get_the_ID();
            			// Get the event date
						$event_date = get_field('event_date', $id); 
        				?>
                        <div class="featured-events">
                        <?php if ( has_post_thumbnail() ) { ?>
                   			 <div class="featured-image">
                        		<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail(); ?></a>
                    		</div>
                		<?php } ?>
                        <div class="event-date">
                           <?php echo $event_date; ?>
                        </div>
                        <div class="overlay">
                        <div class="content">
                            <h3><?php echo get_the_title(); ?></h3>
                	        <p><?php echo get_the_excerpt(); ?></p>
                            <a class="more-link" href="<?php the_permalink(); ?>">Sign Up Here</a>
                        </div>
                        </div>
                        </div>
        			<?php endwhile; ?>
					    <?php wp_reset_postdata(); ?>
                        </div>
		<?php endif; ?>	
</div>