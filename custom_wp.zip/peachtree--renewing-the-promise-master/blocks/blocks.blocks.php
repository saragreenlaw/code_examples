<?php
/**
 * Load Blocks
 */
add_action( 'init', 'register_acf_blocks' );
function register_acf_blocks() {
    register_block_type( get_template_directory() . '/blocks/faq/block.json' );
    register_block_type( get_template_directory() . '/blocks/event-update-block/block.json' );
    register_block_type( get_template_directory() . '/blocks/stories-block/block.json' );
    register_block_type( get_template_directory() . '/blocks/featured-stories-block/block.json' );
    register_block_type( get_template_directory() . '/blocks/home-story-block/block.json' );
    register_block_type( get_template_directory() . '/blocks/information-image-blocks/block.json' );
    register_block_type( get_template_directory() . '/blocks/interior-hero/block.json' );
    register_block_type( get_template_directory() . '/blocks/featured-event-block/block.json' );
    register_block_type( get_template_directory() . '/blocks/left-image-text-block/block.json' );
    register_block_type( get_template_directory() . '/blocks/tabs/block.json' );
    register_block_type( get_template_directory() . '/blocks/icons/block.json' );
    register_block_type( get_template_directory() . '/blocks/event-update-post-block/block.json' );
}

