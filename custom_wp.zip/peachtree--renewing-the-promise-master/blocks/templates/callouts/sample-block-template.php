<?php include(get_theme_file_path().'/blocks/blocks.settings.php'); ?>

<?php

// Set a Prefix for this block
$prefix = prefix() . '-sample-block-template';

// Add the prefix to All Classes
$all_class .= ' ' . $prefix;

// Get the image
$image = get_field('image');

?>

<div class="<?=$all_classes?>">
    <div class="<?=$prefix?>__image">
    	<img src="<?=$image['url']?>" alt="<?=$image['alt']?>">
    </div>
</div>