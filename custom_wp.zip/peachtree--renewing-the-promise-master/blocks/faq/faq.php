<?php
/**
 * Block template file: faq.php
 *
 * Faq Block Template.
 *
 * @param   array $block The block settings and attributes.
 * @param   string $content The block inner HTML (empty).
 * @param   bool $is_preview True during AJAX preview.
 * @param   (int|string) $post_id The post ID this block is saved to.
 */


// Get the taxonomy terms for the Filters
$taxonomy = 'faq-categories';
$terms = get_terms( array(
    'taxonomy' => $taxonomy,
    'hide_empty' => true,
) );


// Get the FAQ Posts
$faqs = get_posts(array(
  'post_type' => 'faq',
  'numberposts' => -1
));

?>


<div id="faq-nav">

	<?php 
		if( $terms ) {
		    foreach ($terms as $term) { ?>
		        <li>
		        	<a href="#<?php echo $term->slug; ?>"><?php echo $term->name; ?></a>
		        </li>
		    <?php }
		}
	?>

    </div>
<div class="gray-border"></div>
<?php
  $terms = get_terms('faq-categories'); // Taxonomy name
  echo '<ul>';
  foreach($terms as $term) {
      $posts = get_posts(
          array(
             'post_type' => 'faq', // Post type
             'tax_query' => array(
                 array(
                     'taxonomy' => 'faq-categories', // Taxonomy name
                     'field' => 'slug',
                     'terms' => $term->slug
                 )
             ),
             'posts_per_page' => -1
          )
      );
      ?>
      <div class ="faq-category-header">
      <div id ="<?php echo $term->slug; ?>"></div>
      <?php
      echo '<h3>' . $term->name; ?></h3>
      </div>
      <?php
      echo '<ul>';
      foreach($posts as $post) {?>
        <dl class="accordion">
        <dt><a href=""><div class="header"><?php echo $post->post_title; ?></div><div class="acc-icon"></div></a></dt>
        <dd><p><?php echo $post->post_content; ?></p></dd>
 </dl><?php
      }
      echo '</ul>';
  }
  echo '</ul>';
 wp_reset_postdata();
 ?>
 <a href="#" class="top">Back to Top</a>
