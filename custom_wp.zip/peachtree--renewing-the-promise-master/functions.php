<?php

include('inc/core.php');
include('inc/enqueue.php');
include('inc/class.ui.php');
include('inc/menus.php');
include('inc/custom-image-sizes.php');
include('inc/settings.gutenberg.php');
include('inc/customize.php');
include('inc/shortcodes.php');
include('inc/class.HeroSection.php');
include('blocks/load.blocks.php');


// Widget areas
include('inc/widget-areas.php');


