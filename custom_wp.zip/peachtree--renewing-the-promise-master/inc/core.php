<?php

function prefix() {

    if (class_exists('acf') && get_field('client_prefix', 'option') ) {
        return get_field('client_prefix', 'option');
    } else {
	   return "{{CLIENT_PREFIX}}";
    }
}


add_theme_support( 'post-thumbnails' );

// Limit exceprt length
function custom_excerpt_length( $length ) {
	return 25;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

// Remove ...  from excerpt
function new_excerpt_more( $more ) {
    return '';
}
add_filter('excerpt_more', 'new_excerpt_more');


// Setup for Block Theme
if ( ! function_exists( 'lc_blocktheme_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which runs
 * before the init hook.
 */
function lc_blocktheme_setup() {
    // Add support for block styles.
    add_theme_support( 'wp-block-styles' );

    // Enqueue editor styles.
    add_editor_style( 'editor-style.css' );
}
endif;
add_action( 'after_setup_theme', 'lc_blocktheme_setup' );




// Allow (safe) SVG uploads 
function ccc_enable_svg_upload( $upload_mimes ) {
    $upload_mimes['svg'] = 'image/svg+xml';
    $upload_mimes['svgz'] = 'image/svg+xml';
    return $upload_mimes;
}
add_filter( 'upload_mimes', 'ccc_enable_svg_upload', 10, 1 );

function cptui_register_my_cpts_event() {

	/**
	 * Post Type: Events.
	 */

	$labels = [
		"name" => esc_html__( "Events", "peachtree-renewing-the-promise" ),
		"singular_name" => esc_html__( "Event", "peachtree-renewing-the-promise" ),
	];

	$args = [
		"label" => esc_html__( "Events", "peachtree-renewing-the-promise" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"rest_namespace" => "wp/v2",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"can_export" => false,
		"rewrite" => [ "slug" => "event", "with_front" => true ],
		"query_var" => true,
		"supports" => [ "title", "editor", "thumbnail", "excerpt", "custom-fields" ],
		"taxonomies" => [ "category" ],
		"show_in_graphql" => false,
	];

	register_post_type( "event", $args );
}

add_action( 'init', 'cptui_register_my_cpts_event' );




add_filter( 'body_class','hide_featured_image_on_update_from_acf' );
function hide_featured_image_on_update_from_acf( $classes ) {
   	if( is_singular('updates') ) {
		$hide = get_field('hide_featured_image', get_queried_object_id());
		if( $hide == true ) {
			$classes[] = 'hide-featured-image';
		}
	}
    return $classes;
    
}
