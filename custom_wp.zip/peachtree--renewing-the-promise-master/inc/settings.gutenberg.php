<?php
add_theme_support( 'align-wide' );
add_theme_support( 'align-full' );


/**
 * Block Styles
 * 
 */
if ( function_exists( 'register_block_style' ) ) {


    // HEADINGS
    register_block_style(
        'core/heading',
        array(
            'name'         => 'font-family--heading',
            'label'        => __( 'Font: Heading', 'textdomain' ),
            'is_default'   => true,
        )
    );

    register_block_style(
        'core/heading',
        array(
            'name'         => 'font-family--body',
            'label'        => __( 'Font: Body', 'textdomain' ),
            'is_default'   => false,
        )
    );


    // PARAGRAPHS
    register_block_style(
        'core/paragraph',
        array(
            'name'         => 'font-family--body',
            'label'        => __( 'Font: Body', 'textdomain' ),
            'is_default'   => true,
        )
    );
    register_block_style(
        'core/paragraph',
        array(
            'name'         => 'font-family--heading',
            'label'        => __( 'Font: Heading', 'textdomain' ),
            'is_default'   => false,
        )
    );

    // COVER
    register_block_style(
        'core/cover',
        array(
            'name'      => 'small-hero',
            'label'     => 'Small Hero'
        )
    );
    register_block_style(
        'core/cover',
        array(
            'name'      => 'large-cta',
            'label'     => 'Large CTA'
        )
    );

    // BUTTONS
    register_block_style(
        'core/buttons',
        array(
            'name'         => prefix() . '-buttons',
            'label'        => __( prefix() . ' Buttons', 'textdomain' ),
            'is_default'   => true,
        )
    );
    register_block_style(
        'core/button',
        array(
            'name'         => 'main-button',
            'label'        => __( 'Main', 'textdomain' ),
            'is_default'   => true,
        )
    );
    register_block_style(
        'core/button',
        array(
            'name'         => 'alt-button',
            'label'        => __( 'Alt', 'textdomain' ),
        )
    );
    register_block_style(
        'genesis-blocks/gb-button',
        array(
            'name'         => 'main-button',
            'label'        => __( 'Main', 'textdomain' ),
            'is_default'   => true,
        )
    );
    register_block_style(
        'genesis-blocks/gb-button',
        array(
            'name'         => 'alt-button',
            'label'        => __( 'Alt', 'textdomain' ),
        )
    );

    // IMAGE
    register_block_style(
        'core/image',
        array(
            'name'         => '-primary-overlay',
            'label'        => __( 'Primary Overlay', 'textdomain' ),
        )
    );  

    // VIDEO WITH IMAGE
    register_block_style(
        'acf/video-with-image',
        array(
            'name'      => 'small',
            'label'     => 'Small'
        )
    );
    register_block_style(
        'acf/video-with-image',
        array(
            'name'          => 'medium',
            'label'         => 'Medium',
            'is_default'    => true
        )
    );
    register_block_style(
        'acf/video-with-image',
        array(
            'name'      => 'large',
            'label'     => 'Large'
        )
    );

    // QUERY LOOP
    register_block_style(
        'core/query',
        array(
            'name'      => 'testimonials',
            'label'     => 'Testimonials'
        )
    );      
    register_block_style(
        'core/query',
        array(
            'name'      => 'blog-pods',
            'label'     => 'Blog Pods'
        )
    );      


}