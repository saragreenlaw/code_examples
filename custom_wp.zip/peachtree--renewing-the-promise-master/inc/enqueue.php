<?php

    add_action( 'wp_enqueue_scripts', 'ccc_enqueue' );
    function ccc_enqueue() {
	    wp_enqueue_style( prefix().'-web', get_template_directory_uri().'/css/web.css', false, filemtime( get_template_directory() . '/css/web.css' ) );
	    //wp_enqueue_script( 'ccc-common', get_template_directory_uri().'/src/js/common.js', array('jquery'),false,false );

	    wp_enqueue_script( prefix().'-fontawesome', 'https://kit.fontawesome.com/a01141edf2.js', array() );
	    wp_enqueue_script( prefix().'-main', get_template_directory_uri().'/js/main.js', array('jquery'), filemtime( get_template_directory() . '/js/main.js' ), true );

        wp_localize_script( prefix().'-main', 'clientOptions', array( 'path' => get_template_directory_uri() ) );
    }

    // Remove Atomic Blocks Font Awesome
    add_action( 'wp_enqueue_scripts', 'remove_atomic_block_fontawesome', 100 );

    function remove_atomic_block_fontawesome(){
        wp_dequeue_style( 'atomic-blocks-fontawesome' );
    }

    // Add in our styles to Gutenberg
    add_action( 'after_setup_theme', 'add_custom_theme_styles_to_gutenberg' );

    function add_custom_theme_styles_to_gutenberg(){

        add_theme_support( 'editor-styles' ); // if you don't add this line, your stylesheet won't be added
        add_editor_style( get_template_directory_uri().'/css/web.css' ); // tries to include style-editor.css directly from your theme folder

    }


    // Add JS for removing Default Button Styles for Core/Button block
    function enqueue_block_editor_scripts() {
      wp_enqueue_script(
          'theme-block-editor-js',
          get_stylesheet_directory_uri() . '/js/remove-block-styles.js',
          array( 'wp-blocks', 'wp-dom-ready', 'wp-edit-post' ), // specify dependencies to avoid race condition
          '1.0',
          true
      );
    }
    add_action('enqueue_block_editor_assets', 'enqueue_block_editor_scripts');



/**
 * Enqueue scripts for faq
 */
function story_scripts() {
    wp_enqueue_script( 'featured-story-slider', get_stylesheet_directory_uri() . '/js/featured-story-slider.js', array(), '1.0.0', true );
    wp_enqueue_script( 'testimonial-slider', get_stylesheet_directory_uri() . '/js/testimonial-slider.js', array(), '1.0.0', true );
    wp_enqueue_script( 'slick', get_stylesheet_directory_uri() . '/js/slick.js', array(), '1.0.0', true );
    wp_enqueue_script( 'slick-min', get_stylesheet_directory_uri() . '/js/slick.min.js', array(), '1.0.0', true );
    wp_enqueue_script( 'tabslet', get_stylesheet_directory_uri() . '/js/jquery.tabslet.min.js', array(), '1.0.0', true );
    wp_enqueue_script( 'tabslet-init', get_stylesheet_directory_uri() . '/js/tab-init.js', array(), '1.0.0', true );
    wp_enqueue_script( 'map-slider-init', get_stylesheet_directory_uri() . '/js/map-page-slider-init.js', array(), '1.0.0', true );
    wp_enqueue_script( 'slick-lightbox', get_stylesheet_directory_uri() . '/js/slick-lightbox.js', array(), '1.0.0', true );
    wp_enqueue_script( 'slick-min-lightbox', get_stylesheet_directory_uri() . '/js/slick-lightbox.min.js', array(), '1.0.0', true );
    wp_enqueue_script( 'slicklightboxmap', get_stylesheet_directory_uri() . '/js/slick-lightbox.min.js.map', array(), '1.0.0', true );
    

}
add_action( 'wp_enqueue_scripts', 'story_scripts' );

?>